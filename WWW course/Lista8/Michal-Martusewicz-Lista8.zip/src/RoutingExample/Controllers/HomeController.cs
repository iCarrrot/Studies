﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoutingExample.Controllers
{
    public class HomeController
    {
        public string Index()
        {
            return "Hello world again!";
        }
    }
}
